package com.covid.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CovidSummary {
	
	private String active;
	private String confirmed;
	private String deaths;
	private String lastupdatedtime;
	private String recovered;
	private String state;
	private String statecode;
		

}
