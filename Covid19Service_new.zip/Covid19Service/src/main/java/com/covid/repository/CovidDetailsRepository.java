package com.covid.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.covid.entity.CovidDetail;

@Repository
public interface CovidDetailsRepository extends MongoRepository<CovidDetail, String>{

}
