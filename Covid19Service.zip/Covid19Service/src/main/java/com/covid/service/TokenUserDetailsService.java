package com.covid.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.covid.advice.UserAlreadyExistException;
import com.covid.entity.LoginUser;
import com.covid.pojo.User;
import com.covid.repository.LoginUserRepository;

@Service
public class TokenUserDetailsService implements UserDetailsService {

	@Autowired
	private LoginUserRepository loginUserRepository;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		LoginUser user = loginUserRepository.findByUserName(username);

		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(),
				new ArrayList<>());
	}

	public LoginUser save(User user) {

		LoginUser tempUser = loginUserRepository.findByUserName(user.getUsername());

		if (tempUser != null) {
			throw new UserAlreadyExistException("User Already Existed");
		}

		LoginUser loginUser = new LoginUser();
		loginUser.setUserName(user.getUsername());
		loginUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		return loginUserRepository.save(loginUser);
	}

}
