package com.covid.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.JsonParser;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.covid.advice.StateCodeIsNotPresentException;
import com.covid.entity.CovidDetail;
import com.covid.entity.CovidDetailsStateWise;
import com.covid.pojo.CovidSummary;
import com.covid.pojo.DistrictData;
import com.covid.pojo.StateData;
import com.covid.repository.CovidDetailsRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

@Service
public class CovidDetailsService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	JsonParser jsonParser;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	CovidDetailsRepository covidDetailsRepository;

	@Value("${external.covid.nation.uri}")
	private String NATION_EXT_URL;

	@Value("${external.covid.state.uri}")
	private String STATE_WISE_EXT_URL;

	public List<CovidSummary> getCovidSummary() {

		CovidDetail covidDetails = covidDetailsRepository.findAll(Sort.by(Sort.Direction.DESC, "_id")).get(0);

		List<CovidSummary> listOfCovidSummary = mappedToCovidSummary(covidDetails.getCovidSummaries());

		return listOfCovidSummary;
	}

	public StateData findCovidDetailsByState(String statecode) {

		List<CovidDetailsStateWise> listCds = mongoTemplate.findAll(CovidDetailsStateWise.class, "covidstatesummary");
		CovidDetailsStateWise cds = listCds.get(listCds.size() - 1);
		String cdsStr = cds.getCovideStateDetails();
		ObjectReader or = objectMapper.readerForListOf(ArrayList.class);
		StateData sd = new StateData();
		List<DistrictData> listDistrict = new ArrayList<DistrictData>();
		try {
			JsonNode rootNode = or.readTree(cdsStr);
			rootNode.fields().forEachRemaining(k -> {
				JsonNode jn = k.getValue();
				if (jn.get("statecode").asText().equals(statecode)) {
					sd.setStatecode(statecode);
					JsonNode jn1 = jn.get("districtData");
					jn1.fields().forEachRemaining(j -> {
						DistrictData kk = new DistrictData();
						kk.setDistrictName(j.getKey());
						JsonNode jn3 = j.getValue();
						kk.setActive(jn3.get("active").asText());
						kk.setConfirmed(jn3.get("confirmed").asText());
						kk.setRecovered(jn3.get("recovered").asText());
						listDistrict.add(kk);
					});
				} 
			});
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(listDistrict.isEmpty()) {
			throw new StateCodeIsNotPresentException("State Code is Not Present");
		}
		
		sd.setDistrictData(listDistrict);
		return sd;
	}

	public String updateCovidDetails() {
		String externalResponse = callCovidExternalService();
		CovidDetail cd = new CovidDetail();
		cd.setCovidSummaries(externalResponse);
		covidDetailsRepository.insert(cd);
		return "updated";
	}

	public String updateCovidDetailsStateWise() {
		String externalResponse = callCovidExternalServiceStateWise();
		CovidDetailsStateWise cd = new CovidDetailsStateWise();
		cd.setCovideStateDetails(externalResponse);
		mongoTemplate.insert(cd);
		return "updated";
	}

	private List<CovidSummary> mappedToCovidSummary(String response) {
		List<CovidSummary> listOfCovidSummary = new ArrayList<CovidSummary>();
		try {
			ObjectReader or = objectMapper.readerForListOf(ArrayList.class);
			JsonNode rootNode = or.readTree(response);

			for (int i = 0; i < rootNode.size(); i++) {
				JsonNode childNode = rootNode.get(i);
				CovidSummary cs = new CovidSummary();
				cs.setActive(childNode.findValue("active").asText());
				cs.setConfirmed(childNode.findValue("confirmed").asText());
				cs.setDeaths(childNode.findValue("deaths").asText());
				cs.setLastupdatedtime(childNode.findValue("lastupdatedtime").asText());
				cs.setRecovered(childNode.findValue("recovered").asText());
				cs.setState(childNode.findValue("state").asText());
				cs.setStatecode(childNode.findValue("statecode").asText());
				listOfCovidSummary.add(cs);
			}

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listOfCovidSummary;
	}

	public String callCovidExternalService() {

		String response = "";
		String summaryResponse = restTemplate.getForObject(NATION_EXT_URL, String.class);
		Map<String, Object> summaryMap = jsonParser.parseMap(summaryResponse);
		ArrayList<?> stateWise = (ArrayList<?>) summaryMap.get("statewise");
		try {
			response = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(stateWise);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	public String callCovidExternalServiceStateWise() {
		String summaryResponse = restTemplate.getForObject(STATE_WISE_EXT_URL, String.class);
		return summaryResponse;
	}

}
