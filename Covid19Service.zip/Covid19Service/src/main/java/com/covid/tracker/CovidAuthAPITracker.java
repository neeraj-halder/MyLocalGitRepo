package com.covid.tracker;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class CovidAuthAPITracker {
	
	Logger log = org.slf4j.LoggerFactory.getLogger(this.getClass());
	
	@Before(value = "execution(* com.covid.resource.CovidAuthResource.createAuthenticationToken(..))")
	public void beforeAuthenticateUser(JoinPoint p) {
		log.info("Authentincation API get Called");
	}
	
	@After(value = "execution(* com.covid.resource.CovidAuthResource.createAuthenticationToken(..))")
	public void afterAuthenticateUser(JoinPoint p) {
		log.info("Authentincation is Done");
	}

}
