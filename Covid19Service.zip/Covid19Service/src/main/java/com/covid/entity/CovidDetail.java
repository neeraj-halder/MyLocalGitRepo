package com.covid.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@Document(collection="covidsummary")
public class CovidDetail {
	
	@Id
	private String id;
	private String covidSummaries;

}
