package com.covid.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "LOGINUSER")
@Data
@Setter
@Getter
public class LoginUser {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LOGINUSERID", unique = true, nullable = false)
	private long userId;

	@Column(name = "USERNAME", unique = true, nullable = false)
	private String userName;
	
	@Column(name = "PASSWORD", unique = false, nullable = false)
	@JsonIgnore
	private String password;

}
