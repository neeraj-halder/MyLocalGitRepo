package com.covid.pojo;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;



@Data
@Setter
@Getter
@ToString
public class StateData {
	
	private String statecode;
	private List<DistrictData> districtData;
	

}
