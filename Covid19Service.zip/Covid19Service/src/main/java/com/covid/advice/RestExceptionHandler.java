package com.covid.advice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = { ConstraintViolationException.class })
	protected ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException e) {
		Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
		StringBuilder strBuilder = new StringBuilder();
		for (ConstraintViolation<?> violation : violations) {
			strBuilder.append(violation.getMessage() + "\n");
		}
		return new ResponseEntity(strBuilder, HttpStatus.BAD_REQUEST);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<FieldError> listError = ex.getBindingResult().getFieldErrors();
		StringBuilder sb = new StringBuilder();

		listError.forEach(k -> sb.append(k.getDefaultMessage()).append(" - "));

		ErrorDetails errorDetails = new ErrorDetails(new Date(), "Input details are not found", sb.toString());
		return new ResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(UserAlreadyExistException.class)
	protected ResponseEntity<Object> handleUserAlreadyExist(UserAlreadyExistException ex) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		String error = new String("User Existed");
		return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(StateCodeIsNotPresentException.class)
	protected ResponseEntity<Object> handleStateCodeIsNotFound(StateCodeIsNotPresentException ex) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		String error = new String("State Code Data is not Found");
		return new ResponseEntity(error, HttpStatus.NOT_FOUND);
	}

}
