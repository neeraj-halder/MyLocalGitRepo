package com.covid.resource;

import java.util.List;

import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.covid.advice.StateCodeIsNotPresentException;
import com.covid.pojo.CovidSummaries;
import com.covid.pojo.CovidSummary;
import com.covid.pojo.StateData;
import com.covid.service.CovidDetailsService;

@RestController
@CrossOrigin
@RequestMapping("/covid")
public class CovidDetailsResource {

	Logger log = org.slf4j.LoggerFactory.getLogger(this.getClass());

	@Autowired
	CovidDetailsService covidDetailsService;

	@RequestMapping(value = "/summary", method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CovidSummaries> getCovidSummary() {
		List<CovidSummary> summaries = covidDetailsService.getCovidSummary();
		CovidSummaries css = new CovidSummaries();
		css.setSummaries(summaries);
		return new ResponseEntity<CovidSummaries>(css, HttpStatus.OK);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateCovidDetails() {
		return covidDetailsService.updateCovidDetails();
	}

	@RequestMapping(value = "/updatestate", method = 
			RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateCovidDetailsStateWise() {
		return covidDetailsService.updateCovidDetailsStateWise();
	}

	@RequestMapping(value = "/state/{statecode}", method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<StateData> getCovidDetailsStateWise(
			@PathVariable("statecode") 
			@Size(max = 2, message = "should be max 2 character") String statecode) {
		StateData sd = covidDetailsService.findCovidDetailsByState(statecode);
		return new ResponseEntity<StateData>(sd, HttpStatus.OK);
	}

}
