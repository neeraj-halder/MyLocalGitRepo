package com.covid.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.covid.entity.LoginUser;

@Repository
public interface LoginUserRepository extends CrudRepository<LoginUser, Integer> {
	public LoginUser findByUserName(String username);
}
