package com.covid;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

@SpringBootTest
@AutoConfigureMockMvc
class Covid19ServiceApplicationTests {

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	ObjectMapper objectMapper;

	private String token;

	@BeforeTestClass
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	void authenticateUser() throws Exception {
		MvcResult mr = mockMvc
				.perform(get("/covid/authenticate").param("username", "neeraj").param("password", "test123"))
				.andDo(print()).andExpect(status().isOk()).andExpect(content().contentType("application/json"))
				.andExpect(jsonPath("$.token").exists()).andReturn();

		ObjectReader or = objectMapper.reader();
		JsonNode rootNode = or.readTree(mr.getResponse().getContentAsString());
		token = rootNode.get("token").asText();

	}

	@Test
	void getCovidSummaryDetails() throws Exception {
		authenticateUser(); // Calling this function to get the token

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);

		MvcResult mr = mockMvc.perform(get("/covid/summary").headers(headers).param("", "").param("", ""))
				.andDo(print()).andExpect(status().isOk()).andExpect(content().contentType("application/json"))
				.andExpect(jsonPath("$.token").exists()).andReturn();
	}

}
